echo -n "Running examples: 1.."
../Src/gulp < example1.gin  > example1.got
echo -n "2.."
../Src/gulp < example2.gin  > example2.got
echo -n "3.."
../Src/gulp < example3.gin  > example3.got
echo -n "4.."
../Src/gulp < example4.gin  > example4.got
echo -n "5.."
../Src/gulp < example5.gin  > example5.got
echo -n "6.."
../Src/gulp < example6.gin  > example6.got
echo -n "7a.."
../Src/gulp < example7a.gin > example7a.got
echo -n "7b.."
../Src/gulp < example7b.gin > example7b.got
echo -n "8.."
../Src/gulp < example8.gin  > example8.got
echo -n "9.."
../Src/gulp < example9.gin  > example9.got
echo "10.."
../Src/gulp < example10.gin > example10.got
echo -n "11.."
../Src/gulp < example11.gin > example11.got
echo -n "12.."
../Src/gulp < example12.gin > example12.got
echo -n "13.."
../Src/gulp < example13.gin > example13.got
echo -n "14.."
../Src/gulp < example14.gin > example14.got
echo -n "15.."
../Src/gulp < example15.gin > example15.got
echo -n "16.."
../Src/gulp < example16.gin > example16.got
echo -n "17.."
../Src/gulp < example17.gin > example17.got
echo -n "17a.."
../Src/gulp < example17a.gin > example17a.got
echo -n "18.."
../Src/gulp < example18.gin > example18.got
echo -n "19.."
../Src/gulp < example19.gin > example19.got
echo "20.."
../Src/gulp < example20.gin > example20.got
echo -n "21.."
../Src/gulp < example21.gin > example21.got
echo -n "22.."
../Src/gulp < example22.gin > example22.got
echo -n "23.."
../Src/gulp < example23.gin > example23.got
echo -n "24.."
../Src/gulp < example24.gin > example24.got
echo -n "25.."
../Src/gulp < example25.gin > example25.got
echo -n "26.."
../Src/gulp < example26.gin > example26.got
echo -n "27.."
../Src/gulp < example27.gin > example27.got
echo -n "28.."
../Src/gulp < example28.gin > example28.got
echo -n "29.."
../Src/gulp < example29.gin > example29.got
echo "30.."
../Src/gulp < example30.gin > example30.got
echo -n "31.."
../Src/gulp < example31.gin > example31.got
echo -n "32.."
../Src/gulp < example32.gin > example32.got
echo -n "33.."
../Src/gulp < example33.gin > example33.got
echo -n "34.."
../Src/gulp < example34.gin > example34.got
echo -n "35.."
../Src/gulp < example35.gin > example35.got
echo -n "36.."
../Src/gulp < example36.gin > example36.got
echo -n "37.."
../Src/gulp < example37.gin > example37.got
echo -n "38.."
../Src/gulp < example38.gin > example38.got
echo -n "39.."
../Src/gulp < example39.gin > example39.got
echo "40.."
../Src/gulp < example40.gin > example40.got
echo -n "41.."
../Src/gulp < example41.gin > example41.got
echo -n "42.."
../Src/gulp < example42.gin > example42.got
echo -n "43.."
../Src/gulp < example43.gin > example43.got
echo -n "44.."
../Src/gulp < example44.gin > example44.got
echo -n "45.."
../Src/gulp < example45.gin > example45.got
echo -n "46.."
../Src/gulp < example46.gin > example46.got
echo -n "47.."
../Src/gulp < example47.gin > example47.got
echo -n "48.."
../Src/gulp < example48.gin > example48.got
echo -n "49.."
../Src/gulp < example49.gin > example49.got
echo "50.."
../Src/gulp < example50.gin > example50.got
echo -n "51.."
../Src/gulp < example51.gin > example51.got
echo -n "52.."
../Src/gulp < example52.gin > example52.got
echo -n "53.."
../Src/gulp < example53.gin > example53.got
echo -n "54.."
../Src/gulp < example54.gin > example54.got
echo -n "55.."
../Src/gulp < example55.gin > example55.got
echo -n "56.."
../Src/gulp < example56.gin > example56.got
echo -n "57.."
../Src/gulp < example57.gin > example57.got
echo -n "58.."
../Src/gulp < example58.gin > example58.got
echo -n "59.."
../Src/gulp < example59.gin > example59.got
echo -n "60.."
../Src/gulp < example60.gin > example60.got
echo -n "61.."
../Src/gulp < example61.gin > example61.got
echo -n "62.."
../Src/gulp < example62.gin > example62.got
echo -n "63.."
../Src/gulp < example63.gin > example63.got
echo -n "64.."
../Src/gulp < example64.gin > example64.got
echo -n "65.."
../Src/gulp < example65.gin > example65.got
echo -n "66.."
../Src/gulp < example66.gin > example66.got
echo -n "67.."
../Src/gulp < example67.gin > example67.got
echo -n "68.."
../Src/gulp < example68.gin > example68.got
echo -n "69.."
../Src/gulp < example69.gin > example69.got
echo -n "70.."
../Src/gulp < example70.gin > example70.got
echo -n "71.."
../Src/gulp < example71.gin > example71.got
echo -n "72.."
../Src/gulp < example72.gin > example72.got
echo -n "73.."
../Src/gulp < example73.gin > example73.got
echo -n "74.."
../Src/gulp < example74.gin > example74.got
echo -n "75.."
../Src/gulp < example75.gin > example75.got
echo -n "76.."
../Src/gulp < example76.gin > example76.got
echo -n "77.."
../Src/gulp < example77.gin > example77.got
